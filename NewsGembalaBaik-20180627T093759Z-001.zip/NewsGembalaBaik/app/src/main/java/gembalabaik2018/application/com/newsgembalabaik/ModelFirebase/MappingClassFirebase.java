package gembalabaik2018.application.com.newsgembalabaik.ModelFirebase;

public class MappingClassFirebase {
    public String classid;

    public MappingClassFirebase(){

    }

    public MappingClassFirebase(String classId) {
        this.classid = classId;
    }

    public String getClassid() {
        return classid;
    }

    public void setClassid(String classid) {
        this.classid = classid;
    }


}
